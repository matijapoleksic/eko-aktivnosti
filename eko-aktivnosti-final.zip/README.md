# Eko Aktivnosti
Jednostavna web aplikacija za evidentiranje ekoloških akcija putem QR koda.
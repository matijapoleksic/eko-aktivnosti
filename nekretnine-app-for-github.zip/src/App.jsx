import React from 'react';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <header className="text-center py-4">
        <h1 className="text-2xl font-bold text-gray-800">Nekretnine CG</h1>
        <p className="text-sm text-gray-500">Pretraži i dodaj nekretnine širom Crne Gore</p>
      </header>

      <main className="max-w-4xl mx-auto">
        <section className="bg-white p-4 rounded shadow mb-6">
          <h2 className="text-lg font-semibold mb-2">Pretraga</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <input type="text" placeholder="Grad (npr. Budva)" className="border p-2 rounded" />
            <select className="border p-2 rounded">
              <option>Tip</option>
              <option>Stan</option>
              <option>Kuća</option>
              <option>Zemljište</option>
            </select>
            <input type="number" placeholder="Cijena od (€)" className="border p-2 rounded" />
            <input type="number" placeholder="Cijena do (€)" className="border p-2 rounded" />
          </div>
        </section>

        <section className="bg-white p-4 rounded shadow">
          <h2 className="text-lg font-semibold mb-4">Nekretnine</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="border rounded p-2 bg-gray-50">
              <img src="https://via.placeholder.com/300x180" alt="Nekretnina" className="mb-2 rounded" />
              <h3 className="font-bold">Stan u Podgorici</h3>
              <p className="text-sm text-gray-600">Cijena: 85.000 €</p>
              <p className="text-sm text-gray-600">Tip: Stan</p>
              <p className="text-sm text-gray-600">Grad: Podgorica</p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
